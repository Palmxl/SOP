#include <stdio.h>       // Para funciones de entrada/salida
#include <stdlib.h>      // Para manejo de memoria y funciones como atoi, rand
#include <unistd.h>      // Para funciones fork(), getpid()
#include <sys/wait.h>    // Para usar wait()
#include <sys/time.h>    // Para medir tiempo
#include <time.h>        // Para inicializar la semilla aleatoria con time()

// Variables globales para capturar el tiempo de inicio y fin
struct timeval inicio, fin;

// Función que guarda el tiempo de inicio
void InicioMuestra(){
	gettimeofday(&inicio, (void *)0); // Captura el tiempo actual
}

// Función que guarda el tiempo de fin y calcula la duración en microsegundos
void FinMuestra(){
	gettimeofday(&fin, (void *)0); // Captura el tiempo final
	fin.tv_usec -= inicio.tv_usec;
	fin.tv_sec  -= inicio.tv_sec;
	double tiempo = (double) (fin.tv_sec*1000000 + fin.tv_usec); // Tiempo en microsegundos
	printf("%9.0f \n", tiempo); // Muestra el tiempo
}

// Función para multiplicar una sección de la matriz (por proceso)
void multiMatrix(double *mA, double *mB, double *mC, int D, int filaI, int filaF) {
	double Suma, *pA, *pB;

    for (int i = filaI; i < filaF; i++) {         // Recorre filas asignadas
        for (int j = 0; j < D; j++) {             // Recorre columnas de B
			Suma = 0;
			pA = mA + i * D;                      // Apunta al inicio de la fila i de A
			pB = mB + j;                          // Apunta a la columna j de B
            for (int k = 0; k < D; k++, pA++, pB += D) {
				Suma += *pA * *pB;               // Multiplicación y suma acumulada
            }
			mC[i * D + j] = Suma;                // Guarda el resultado en C
        }
    }
}

// Imprime la matriz si su dimensión es menor a 9 (para pruebas)
void impMatrix(double *matrix, int D) {
	if (D < 9) {
    	printf("\nImpresión ...\n");
    	for (int i = 0; i < D * D; i++, matrix++) {
			if(i % D == 0) printf("\n");
            printf(" %f ", *matrix);
        }
        printf("\n ");
    }
}

// Inicializa las matrices A y B con valores aleatorios entre 0 y 9
void iniMatrix(double *mA, double *mB, int D){
	for (int i = 0; i < D * D; i++, mA++, mB++){
        *mA = rand() % 10;
        *mB = rand() % 10;
    }
}

// Función principal del programa
int main(int argc, char *argv[]) {
	// Verifica que se pasaron los argumentos necesarios
	if (argc < 3) {
		printf("\n \t\tUse: $./nom_ejecutable Size Hilos \n");
		exit(0);
	}

	int N      = (int) atoi(argv[1]);   // Tamaño de la matriz NxN
	int num_P  = (int) atoi(argv[2]);   // Número de procesos a usar

    // Reserva de memoria para las matrices
    double *matA = (double *) calloc(N * N, sizeof(double));
    double *matB = (double *) calloc(N * N, sizeof(double));
    double *matC = (double *) calloc(N * N, sizeof(double));

    srand(time(0));             // Inicializa la semilla de aleatoriedad
    iniMatrix(matA, matB, N);   // Llena A y B con valores aleatorios
    impMatrix(matA, N);         // Imprime A si es pequeña
    impMatrix(matB, N);         // Imprime B si es pequeña

    int rows_per_process = N / num_P; // Calcula cuántas filas hará cada proceso

	InicioMuestra(); // Marca inicio del tiempo

    for (int i = 0; i < num_P; i++) {
        pid_t pid = fork(); // Crea un nuevo proceso

        if (pid == 0) { // Código que ejecuta el proceso hijo
            int start_row = i * rows_per_process;
            int end_row = (i == num_P - 1) ? N : start_row + rows_per_process;

			multiMatrix(matA, matB, matC, N, start_row, end_row); // Multiplica su sección

			if(N < 9){
            	// Muestra la parte de C que calculó este proceso
           		printf("\nChild PID %d calculated rows %d to %d:\n", getpid(), start_row, end_row - 1);
            	for (int r = start_row; r < end_row; r++) {
                	for (int c = 0; c < N; c++) {
                    	printf(" %f ", matC[N * r + c]);
                	}
                	printf("\n");
            	}
			}
            exit(0); // Termina el proceso hijo
        } else if (pid < 0) {
            perror("fork failed"); // Error al crear proceso
            exit(1);
        }
    }

    // El proceso padre espera que todos los hijos terminen
    for (int i = 0; i < num_P; i++) {
        wait(NULL);
    }

	FinMuestra(); // Marca fin del tiempo y muestra duración

	// Libera la memoria de las matrices
	free(matA);
	free(matB);
	free(matC);

    return 0; // Fin del programa
}
