/*#######################################################################################
 #* Fecha: 20 sep 2025
 #* Autor: J. Corredor, PhD
 #* Tema: Programación Modular en C
 #* 	- Programa Multiplicación de Matrices algoritmo clásico
 #* 	- Paralelismo con OpenMP
######################################################################################*/

#include <stdio.h>       // Para printf, etc.
#include <stdlib.h>      // Para malloc, calloc, atoi, etc.
#include <string.h>      // (No usado directamente aquí, pero común en headers estándar)
#include <time.h>        // Para srand() y time()
#include <sys/time.h>    // Para medir tiempo con gettimeofday()
#include <omp.h>         // Librería OpenMP para paralelismo

// Variables globales para medir tiempo
struct timeval inicio, fin; 

// Función que marca el tiempo de inicio
void InicioMuestra(){
	gettimeofday(&inicio, (void *)0);
}

// Función que marca el tiempo final y calcula la duración
void FinMuestra(){
	gettimeofday(&fin, (void *)0);
	fin.tv_usec -= inicio.tv_usec;
	fin.tv_sec  -= inicio.tv_sec;
	double tiempo = (double) (fin.tv_sec*1000000 + fin.tv_usec); 
	printf("%9.0f \n", tiempo);
}

// Función para imprimir matrices si son pequeñas
void impMatrix(size_t *matrix, int D){
	printf("\n");
	if(D < 9){  // Solo imprime si el tamaño de la matriz es pequeño
		for(int i = 0; i < D * D; i++){
			if(i % D == 0) printf("\n");       // Salto de línea al cambiar de fila
			printf("%zu ", matrix[i]);        // Imprime el valor de la celda
		}
		printf("\n**-----------------------------**\n");
	}
}

// Función para inicializar las matrices A y B
void iniMatrix(size_t *m1, size_t *m2, int D){
	for(int i = 0; i < D * D; i++, m1++, m2++){
		*m1 = i * 2;    // También podrías usar: rand() % 10
		*m2 = i + 2;    // También podrías usar: rand() % 10
	}
}

// Función que realiza la multiplicación de matrices con OpenMP
void multiMatrix(size_t *mA, size_t *mB, size_t *mC, int D){
	size_t Suma, *pA, *pB;

	#pragma omp parallel        // Inicia región paralela
	{
	#pragma omp for            // Distribuye los ciclos entre los hilos
	for(int i = 0; i < D; i++){
		for(int j = 0; j < D; j++){
			pA = mA + i * D;    // Apunta al inicio de la fila i de A
			pB = mB + j;        // Apunta al inicio de la columna j de B (en forma transpuesta)

			Suma = 0.0;

			for(int k = 0; k < D; k++, pA++, pB += D){
				Suma += *pA * *pB;  // Multiplicación y acumulación
			}

			mC[i * D + j] = Suma;  // Guarda el resultado en la posición (i, j)
		}
	}
	}
}

// Función principal del programa
int main(int argc, char *argv[]){
	// Validación de argumentos
	if(argc < 3){
		printf("\n Use: $./clasicaOpenMP SIZE Hilos \n\n");
		exit(0);
	}

	// Lectura de argumentos
	int N  = atoi(argv[1]);  // Tamaño de la matriz
	int TH = atoi(argv[2]);  // Número de hilos

	// Reserva dinámica de memoria para matrices
	size_t *matrixA = (size_t *)calloc(N * N, sizeof(size_t));
	size_t *matrixB = (size_t *)calloc(N * N, sizeof(size_t));
	size_t *matrixC = (size_t *)calloc(N * N, sizeof(size_t));

	srand(time(NULL));        // Inicializa la semilla aleatoria (aunque no se usa aquí con rand)

	omp_set_num_threads(TH);  // Define el número de hilos para OpenMP

	// Inicialización e impresión (si aplica)
	iniMatrix(matrixA, matrixB, N);
	impMatrix(matrixA, N);
	impMatrix(matrixB, N);

	// Medición del tiempo de ejecución de la multiplicación
	InicioMuestra();
	multiMatrix(matrixA, matrixB, matrixC, N);
	FinMuestra();

	// Imprimir matriz resultado (si es pequeña)
	impMatrix(matrixC, N);

	// Liberación de memoria
	free(matrixA);
	free(matrixB);
	free(matrixC);

	return 0;
}
