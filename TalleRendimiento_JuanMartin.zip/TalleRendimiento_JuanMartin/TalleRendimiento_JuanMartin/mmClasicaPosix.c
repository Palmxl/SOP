#include <stdio.h>        // Para funciones de entrada/salida (printf)
#include <pthread.h>      // Para manejo de hilos POSIX
#include <unistd.h>       // Para funciones estándar del sistema (como sleep, etc.)
#include <stdlib.h>       // Para malloc, calloc, atoi, rand, etc.
#include <time.h>         // Para time(), srand()
#include <sys/time.h>     // Para medir el tiempo con gettimeofday()

// Tamaño total de la memoria compartida
#define DATA_SIZE (1024*1024*64*3) 

// Mutex para sincronización (aunque en este caso no es necesario realmente)
pthread_mutex_t MM_mutex;

// Área de memoria compartida para las tres matrices
static double MEM_CHUNK[DATA_SIZE];
double *mA, *mB, *mC; // Punteros a matrices A, B y C

// Estructura de parámetros que se le pasa a cada hilo
struct parametros {
	int nH;  // Total de hilos
	int idH; // ID del hilo actual
	int N;   // Tamaño de la matriz (NxN)
};

// Variables globales para cronómetro
struct timeval inicio, fin;

// Marca el inicio de la medición de tiempo
void InicioMuestra() {
	gettimeofday(&inicio, (void *)0);
}

// Marca el final de la medición y muestra duración
void FinMuestra() {
	gettimeofday(&fin, (void *)0);
	fin.tv_usec -= inicio.tv_usec;
	fin.tv_sec  -= inicio.tv_sec;
	double tiempo = (double) (fin.tv_sec*1000000 + fin.tv_usec); // Tiempo en microsegundos
	printf("%9.0f \n", tiempo);
}

// Inicializa las matrices A y B con valores aleatorios entre 0 y 9, y C en 0
void iniMatrix(int SZ) {
	for(int i = 0; i < SZ * SZ; i++) {
		mA[i] = rand() % 10;
		mB[i] = rand() % 10;
		mC[i] = 0;
	}	
}

// Imprime la matriz si el tamaño es menor a 12
void impMatrix(int sz, double *matriz) {
	if(sz < 12) {
		for(int i = 0; i < sz * sz; i++) {
			if(i % sz == 0) printf("\n");
			printf(" %.3f ", matriz[i]);
		}
		printf("\n>-------------------->\n");
	}
}

// Función que ejecutará cada hilo para multiplicar una porción de la matriz
void *multiMatrix(void *variables) {
	struct parametros *data = (struct parametros *) variables;

	int idH = data->idH;
	int nH  = data->nH;
	int N   = data->N;

	// Cálculo de rango de filas que le toca a este hilo
	int ini = (N / nH) * idH;
	int fin = (N / nH) * (idH + 1);

	// Multiplicación clásica de matrices para las filas asignadas
	for (int i = ini; i < fin; i++) {
		for (int j = 0; j < N; j++) {
			double *pA, *pB, sumaTemp = 0.0;
			pA = mA + (i * N);  // Inicio de fila i
			pB = mB + j;        // Inicio de columna j (transpuesta implícita)

			for (int k = 0; k < N; k++, pA++, pB += N) {
				sumaTemp += (*pA * *pB);
			}
			mC[i * N + j] = sumaTemp; // Guarda resultado
		}
	}

	// Mutex innecesario aquí, pero requerido por convención
	pthread_mutex_lock(&MM_mutex);
	pthread_mutex_unlock(&MM_mutex);

	pthread_exit(NULL); // Termina el hilo
}

int main(int argc, char *argv[]) {
	// Validación de argumentos
	if (argc < 3) {
		printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
		exit(0);	
	}

	int SZ = atoi(argv[1]);        // Tamaño de matriz
	int n_threads = atoi(argv[2]); // Número de hilos

	// Declaración de hilos y atributos
	pthread_t p[n_threads];
	pthread_attr_t atrMM;

	// Asignación de punteros dentro de la memoria compartida
	mA = MEM_CHUNK;
	mB = mA + SZ * SZ;
	mC = mB + SZ * SZ;

	// Inicialización de matrices y visualización
	iniMatrix(SZ);
	impMatrix(SZ, mA);
	impMatrix(SZ, mB);

	// Medición de tiempo
	InicioMuestra();

	// Inicialización de atributos de hilos y mutex
	pthread_mutex_init(&MM_mutex, NULL);
	pthread_attr_init(&atrMM);
	pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE);

	// Creación de hilos
	for (int j = 0; j < n_threads; j++) {
		struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros));
		datos->idH = j;
		datos->nH  = n_threads;
		datos->N   = SZ;

		pthread_create(&p[j], &atrMM, multiMatrix, (void *) datos);
	}

	// Espera a que todos los hilos terminen
	for (int j = 0; j < n_threads; j++) {
		pthread_join(p[j], NULL);
	}

	// Finaliza cronómetro
	FinMuestra();

	// Muestra matriz resultado si es pequeña
	impMatrix(SZ, mC);

	// Limpieza de recursos
	pthread_attr_destroy(&atrMM);
	pthread_mutex_destroy(&MM_mutex);
	pthread_exit(NULL); // Finaliza el programa correctamente
}